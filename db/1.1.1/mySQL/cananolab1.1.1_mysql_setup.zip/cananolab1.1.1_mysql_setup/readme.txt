		-----------------------------------
		release 1.1.1 patch for mySQL 5.0.x
		-----------------------------------

This document explains the necessary steps to configure caNanoLab release 1.1.1 
to use with an mySQL database version 5.0.x.  It assumes JBoss has been previously
configured with CSM configuration files.  For more information on how to configure
CSM in JBoss, please refer to the caNanoLab 1.1.1 installation guide (the guide was
written for Oracle specifics, refer the following chnages for mySQL installation).

1.  Install mySQL server 5.0.x and create a new user called cananolab_app with password
go!234.  Note the user name and password can be different from the default ones if
one makes the appropriate changes in files mysql-ds.xml and logic-config-excerpt.xml.

2.  Extract the zip file to a temp location, e.g. C:\cananolab111_mysql_setup.

3.  Go to this temp location, run the following command 
at the dos prompt to create a new database cananolab111 with tables and data:
	mysql -h localhost -u root -p < mysql_seed.sql

4.  Put mysql-connector-java-5.0.7-bin.jar into <JBOSS_HOME>/server/default/lib.

5.  Put caNanoLab.csm.hibernate.cfg.xml into <JBOSS_HOME>/server/default/conf.

6.  Insert content of login_config_excerpt.xml into file 
<JBOSS_HOME>/server/default/conf/login-config.xml.  For information on exactly where 
to make the insert, please refer to the caNanoLab 1.1.1 installation guide.

7.  Put mysql-ds.xml and caNanoLabSDK.war into <JBOSS_HOME>/server/default/deploy. 
This file assumes there is a mySQL user called cananolab_app with password go!234.

8.  Delete oracle-ds.xml in <JBOSS_HOME>/server/default/deploy if it exists.

9.  Put orm1.cfg.xml into <CANANOLAB_HOME>/src, replace the existing file.

10. Rebuild caNanoLab application by running the following ant command:
	ant clean build-application

11. Put caNanoLab.war and upt.war into <JBOSS_HOME>/server/default/deploy.  Do not put 
caNanoLabSDK.war there for an updated version is already placed there in step 7.

12. Start Jboss server to access caNanoLab and UPT applications.


-----------------------------------------------------------------------------------------
If you have any questions, please contact Sue Pan at (301)443-6226 or pansu@mail.nih.gov
-----------------------------------------------------------------------------------------