-- ----------------------------------------------------------------------
-- MySQL Migration Toolkit
-- SQL Create Script
-- ----------------------------------------------------------------------

SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS `cananolab111`
  CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `cananolab111`;
-- -------------------------------------
-- Tables

DROP TABLE IF EXISTS `cananolab111`.`agent`;
CREATE TABLE `cananolab111`.`agent` (
  `agent_pk_id` DECIMAL(22, 0) NOT NULL,
  `discriminator` VARCHAR(200) BINARY NULL,
  `description` VARCHAR(2000) BINARY NULL,
  `name` VARCHAR(200) BINARY NULL,
  `other` VARCHAR(200) BINARY NULL,
  `sequence` VARCHAR(2000) BINARY NULL,
  PRIMARY KEY (`agent_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`agent_target`;
CREATE TABLE `cananolab111`.`agent_target` (
  `agent_target_pk_id` DECIMAL(22, 0) NOT NULL,
  `discriminator` VARCHAR(200) BINARY NULL,
  `name` VARCHAR(200) BINARY NULL,
  `description` VARCHAR(2000) BINARY NULL,
  `list_index` DECIMAL(22, 0) NULL,
  `agent_pk_id` DECIMAL(22, 0) NULL,
  PRIMARY KEY (`agent_target_pk_id`),
  CONSTRAINT `fk_agent_target_agent` FOREIGN KEY `fk_agent_target_agent` (`agent_pk_id`)
    REFERENCES `cananolab111`.`agent` (`agent_pk_id`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`assay`;
CREATE TABLE `cananolab111`.`assay` (
  `assay_pk_id` DECIMAL(22, 0) NOT NULL,
  `assay_name` VARCHAR(200) BINARY NULL,
  `description` VARCHAR(4000) BINARY NULL,
  `assay_type` VARCHAR(200) BINARY NULL,
  `created_date` DATETIME NULL,
  `created_by` VARCHAR(200) BINARY NULL,
  `assay_type_pk_id` DECIMAL(22, 0) NULL,
  `protocol_pk_id` DECIMAL(22, 0) NULL,
  PRIMARY KEY (`assay_pk_id`),
  CONSTRAINT `sys_c00242909` FOREIGN KEY `sys_c00242909` (`protocol_pk_id`)
    REFERENCES `cananolab111`.`protocol` (`protocol_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `sys_c00242910` FOREIGN KEY `sys_c00242910` (`assay_type_pk_id`)
    REFERENCES `cananolab111`.`assay_type` (`assay_type_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`assay_type`;
CREATE TABLE `cananolab111`.`assay_type` (
  `assay_type_pk_id` DECIMAL(22, 0) NOT NULL,
  `assay_type_name` VARCHAR(200) BINARY NULL,
  `description` VARCHAR(4000) BINARY NULL,
  `execute_order` VARCHAR(10) BINARY NULL,
  PRIMARY KEY (`assay_type_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`associated_file`;
CREATE TABLE `cananolab111`.`associated_file` (
  `associated_file_pk_id` DECIMAL(22, 0) NULL
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`carbon_nanotube_composition`;
CREATE TABLE `cananolab111`.`carbon_nanotube_composition` (
  `chirality` VARCHAR(100) BINARY NULL,
  `growth_diameter` DECIMAL(22, 0) NULL,
  `average_length` DECIMAL(22, 0) NULL,
  `wall_type` VARCHAR(100) BINARY NULL,
  `cn_composition_pk_id` DECIMAL(22, 0) NOT NULL,
  PRIMARY KEY (`cn_composition_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`characterization`;
CREATE TABLE `cananolab111`.`characterization` (
  `characterization_pk_id` DECIMAL(22, 0) NOT NULL,
  `classification` VARCHAR(200) BINARY NULL,
  `source` VARCHAR(200) BINARY NULL,
  `description` VARCHAR(2000) BINARY NULL,
  `identifier_name` VARCHAR(500) BINARY NULL,
  `name` VARCHAR(100) BINARY NULL,
  `discriminator` VARCHAR(50) BINARY NULL,
  `created_date` DATETIME NULL,
  `created_by` VARCHAR(200) BINARY NULL,
  `char_protocol_pk_id` DECIMAL(22, 0) NULL,
  `instrument_config_pk_id` DECIMAL(22, 0) NULL,
  PRIMARY KEY (`characterization_pk_id`),
  CONSTRAINT `sys_c00242933` FOREIGN KEY `sys_c00242933` (`char_protocol_pk_id`)
    REFERENCES `cananolab111`.`characterization_protocol` (`char_protocol_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`characterization_protocol`;
CREATE TABLE `cananolab111`.`characterization_protocol` (
  `char_protocol_pk_id` DECIMAL(22, 0) NOT NULL,
  `name` VARCHAR(200) BINARY NULL,
  `version` VARCHAR(100) BINARY NULL,
  PRIMARY KEY (`char_protocol_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`characterization_table`;
CREATE TABLE `cananolab111`.`characterization_table` (
  `char_table_pk_id` DECIMAL(22, 0) NOT NULL,
  `file_path` VARCHAR(500) BINARY NULL,
  `type` VARCHAR(100) BINARY NULL,
  `characterization_pk_id` DECIMAL(22, 0) NULL,
  `list_index` DECIMAL(22, 0) NULL,
  `labfile_pk_id` DECIMAL(22, 0) NULL,
  PRIMARY KEY (`char_table_pk_id`),
  CONSTRAINT `sys_c00242934` FOREIGN KEY `sys_c00242934` (`characterization_pk_id`)
    REFERENCES `cananolab111`.`characterization` (`characterization_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`composing_element`;
CREATE TABLE `cananolab111`.`composing_element` (
  `composing_element_pk_id` DECIMAL(22, 0) NOT NULL,
  `element_type` VARCHAR(100) BINARY NULL,
  `chemical_name` VARCHAR(200) BINARY NULL,
  `description` VARCHAR(2000) BINARY NULL,
  `characterization_pk_id` DECIMAL(22, 0) NULL,
  `list_index` DECIMAL(22, 0) NULL,
  PRIMARY KEY (`composing_element_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`contact`;
CREATE TABLE `cananolab111`.`contact` (
  `contact_pk_id` DECIMAL(38, 0) NOT NULL,
  `first_name` VARCHAR(100) BINARY NOT NULL,
  `last_name` VARCHAR(100) BINARY NOT NULL,
  `title` VARCHAR(100) BINARY NULL,
  `phone_number` VARCHAR(15) BINARY NULL,
  `email` VARCHAR(100) BINARY NULL,
  `update_date` DATETIME NOT NULL,
  `middle_name` VARCHAR(100) BINARY NULL,
  `fax` VARCHAR(20) BINARY NULL,
  `address` VARCHAR(200) BINARY NULL,
  `city` VARCHAR(100) BINARY NULL,
  `state` VARCHAR(100) BINARY NULL,
  `country` VARCHAR(100) BINARY NULL,
  `postal_code` VARCHAR(10) BINARY NULL,
  `pi_name` VARCHAR(200) BINARY NULL,
  PRIMARY KEY (`contact_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`container_storage_location`;
CREATE TABLE `cananolab111`.`container_storage_location` (
  `sample_container_pk_id` DECIMAL(22, 0) NOT NULL,
  `storage_pk_id` DECIMAL(22, 0) NOT NULL,
  CONSTRAINT `sys_c00242911` FOREIGN KEY `sys_c00242911` (`sample_container_pk_id`)
    REFERENCES `cananolab111`.`sample_container` (`sample_container_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `sys_c00242912` FOREIGN KEY `sys_c00242912` (`storage_pk_id`)
    REFERENCES `cananolab111`.`storage` (`storage_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`cytotoxicity`;
CREATE TABLE `cananolab111`.`cytotoxicity` (
  `cytotoxicity_pk_id` DECIMAL(22, 0) NOT NULL,
  `cell_line` VARCHAR(200) BINARY NULL,
  `cell_death_method` VARCHAR(200) BINARY NULL,
  PRIMARY KEY (`cytotoxicity_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`data_status`;
CREATE TABLE `cananolab111`.`data_status` (
  `data_status_pk_id` DECIMAL(22, 0) NOT NULL,
  `status` VARCHAR(20) BINARY NULL,
  `reason` VARCHAR(2000) BINARY NULL,
  PRIMARY KEY (`data_status_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`dendrimer_composition`;
CREATE TABLE `cananolab111`.`dendrimer_composition` (
  `generation` DECIMAL(22, 0) NULL,
  `molecular_formula` VARCHAR(200) BINARY NULL,
  `repeat_unit` VARCHAR(100) BINARY NULL,
  `branch` VARCHAR(200) BINARY NULL,
  `d_composition_pk_id` DECIMAL(22, 0) NOT NULL,
  PRIMARY KEY (`d_composition_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`derived_data_file`;
CREATE TABLE `cananolab111`.`derived_data_file` (
  `derived_file_pk_id` DECIMAL(22, 0) NOT NULL,
  PRIMARY KEY (`derived_file_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`derived_sample_container`;
CREATE TABLE `cananolab111`.`derived_sample_container` (
  `parent_container_id` DECIMAL(22, 0) NOT NULL,
  `sample_container_pk_id` DECIMAL(22, 0) NOT NULL,
  PRIMARY KEY (`parent_container_id`, `sample_container_pk_id`),
  CONSTRAINT `sys_c00242913` FOREIGN KEY `sys_c00242913` (`sample_container_pk_id`)
    REFERENCES `cananolab111`.`sample_container` (`sample_container_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `sys_c00242914` FOREIGN KEY `sys_c00242914` (`parent_container_id`)
    REFERENCES `cananolab111`.`sample_container` (`sample_container_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`emulsion_composition`;
CREATE TABLE `cananolab111`.`emulsion_composition` (
  `emulsion_type` VARCHAR(200) BINARY NULL,
  `molecular_formula` VARCHAR(200) BINARY NULL,
  `polymer_name` VARCHAR(200) BINARY NULL,
  `is_polymerized` DECIMAL(22, 0) NULL,
  `e_composition_pk_id` DECIMAL(22, 0) NOT NULL,
  PRIMARY KEY (`e_composition_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`fullerene_composition`;
CREATE TABLE `cananolab111`.`fullerene_composition` (
  `number_of_carbon` VARCHAR(200) BINARY NULL,
  `f_composition_pk_id` DECIMAL(22, 0) NOT NULL,
  PRIMARY KEY (`f_composition_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`hibernate_unique_key`;
CREATE TABLE `cananolab111`.`hibernate_unique_key` (
  `next_hi` DECIMAL(22, 0) NOT NULL
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`instrument`;
CREATE TABLE `cananolab111`.`instrument` (
  `instrument_pk_id` DECIMAL(22, 0) NOT NULL,
  `type` VARCHAR(200) BINARY NULL,
  `abbreviation` VARCHAR(50) BINARY NULL,
  `manufacturer` VARCHAR(2000) BINARY NULL,
  PRIMARY KEY (`instrument_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`instrument_config`;
CREATE TABLE `cananolab111`.`instrument_config` (
  `instrument_config_pk_id` DECIMAL(22, 0) NOT NULL,
  `description` VARCHAR(4000) BINARY NULL,
  `instrument_pk_id` DECIMAL(22, 0) NOT NULL,
  UNIQUE INDEX `pk_instrument_config` (`instrument_config_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`keyword`;
CREATE TABLE `cananolab111`.`keyword` (
  `keyword_pk_id` DECIMAL(22, 0) NOT NULL,
  `name` VARCHAR(100) BINARY NULL,
  PRIMARY KEY (`keyword_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`keyword_derived_file`;
CREATE TABLE `cananolab111`.`keyword_derived_file` (
  `keyword_pk_id` DECIMAL(22, 0) NOT NULL,
  `derived_file_pk_id` DECIMAL(22, 0) NOT NULL,
  PRIMARY KEY (`keyword_pk_id`, `derived_file_pk_id`),
  CONSTRAINT `fk_keyword_d_file_d_file` FOREIGN KEY `fk_keyword_d_file_d_file` (`derived_file_pk_id`)
    REFERENCES `cananolab111`.`derived_data_file` (`derived_file_pk_id`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_keyword_d_file_keyword` FOREIGN KEY `fk_keyword_d_file_keyword` (`keyword_pk_id`)
    REFERENCES `cananolab111`.`keyword` (`keyword_pk_id`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`keyword_nanoparticle`;
CREATE TABLE `cananolab111`.`keyword_nanoparticle` (
  `keyword_pk_id` DECIMAL(22, 0) NOT NULL,
  `nanoparticle_pk_id` DECIMAL(22, 0) NOT NULL,
  PRIMARY KEY (`keyword_pk_id`, `nanoparticle_pk_id`),
  CONSTRAINT `sys_c00242935` FOREIGN KEY `sys_c00242935` (`nanoparticle_pk_id`)
    REFERENCES `cananolab111`.`nanoparticle` (`nanoparticle_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `sys_c00242936` FOREIGN KEY `sys_c00242936` (`keyword_pk_id`)
    REFERENCES `cananolab111`.`keyword` (`keyword_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`lab_file`;
CREATE TABLE `cananolab111`.`lab_file` (
  `file_pk_id` DECIMAL(22, 0) NOT NULL,
  `file_name` VARCHAR(500) BINARY NULL,
  `file_uri` VARCHAR(500) BINARY NULL,
  `file_type_extension` VARCHAR(100) BINARY NULL,
  `file_source_type` VARCHAR(100) BINARY NULL,
  `version` VARCHAR(200) BINARY NULL,
  `status` VARCHAR(20) BINARY NULL,
  `reason` VARCHAR(2000) BINARY NULL,
  `created_by` VARCHAR(200) BINARY NULL,
  `created_date` DATETIME NULL,
  `sample_sop_pk_id` DECIMAL(22, 0) NULL,
  `run_pk_id` DECIMAL(22, 0) NULL,
  `protocol_pk_id` DECIMAL(22, 0) NULL,
  `data_status_pk_id` DECIMAL(22, 0) NULL,
  `title` VARCHAR(500) BINARY NULL,
  `description` VARCHAR(2000) BINARY NULL,
  `comments` VARCHAR(2000) BINARY NULL,
  PRIMARY KEY (`file_pk_id`),
  CONSTRAINT `sys_c00242915` FOREIGN KEY `sys_c00242915` (`protocol_pk_id`)
    REFERENCES `cananolab111`.`protocol` (`protocol_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `sys_c00242916` FOREIGN KEY `sys_c00242916` (`run_pk_id`)
    REFERENCES `cananolab111`.`run` (`run_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `sys_c00242917` FOREIGN KEY `sys_c00242917` (`sample_sop_pk_id`)
    REFERENCES `cananolab111`.`sample_sop` (`sample_sop_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `sys_c00242918` FOREIGN KEY `sys_c00242918` (`data_status_pk_id`)
    REFERENCES `cananolab111`.`data_status` (`data_status_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`linkage`;
CREATE TABLE `cananolab111`.`linkage` (
  `linkage_pk_id` DECIMAL(22, 0) NOT NULL,
  `description` VARCHAR(2000) BINARY NULL,
  `discriminator` VARCHAR(200) BINARY NULL,
  `bond_type` VARCHAR(200) BINARY NULL,
  `localization` VARCHAR(200) BINARY NULL,
  `function_pk_id` DECIMAL(22, 0) NULL,
  `list_index` DECIMAL(22, 0) NULL,
  `agent_pk_id` DECIMAL(22, 0) NULL,
  PRIMARY KEY (`linkage_pk_id`),
  CONSTRAINT `fk_linkage_agent` FOREIGN KEY `fk_linkage_agent` (`agent_pk_id`)
    REFERENCES `cananolab111`.`agent` (`agent_pk_id`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_linkage_function` FOREIGN KEY `fk_linkage_function` (`function_pk_id`)
    REFERENCES `cananolab111`.`particle_function` (`particle_function_pk_id`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`liposome_composition`;
CREATE TABLE `cananolab111`.`liposome_composition` (
  `is_polymerized` DECIMAL(22, 0) NULL,
  `polymer_name` VARCHAR(200) BINARY NULL,
  `l_composition_pk_id` DECIMAL(22, 0) NOT NULL,
  PRIMARY KEY (`l_composition_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`measure_unit`;
CREATE TABLE `cananolab111`.`measure_unit` (
  `measure_unit_pk_id` DECIMAL(22, 0) NOT NULL,
  `unit_name` VARCHAR(50) BINARY NULL,
  `description` VARCHAR(1000) BINARY NULL,
  `unit_type` VARCHAR(100) BINARY NULL,
  PRIMARY KEY (`measure_unit_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`morphology`;
CREATE TABLE `cananolab111`.`morphology` (
  `morphology_pk_id` DECIMAL(22, 0) NOT NULL,
  `type` VARCHAR(100) BINARY NULL,
  PRIMARY KEY (`morphology_pk_id`),
  CONSTRAINT `sys_c00242937` FOREIGN KEY `sys_c00242937` (`morphology_pk_id`)
    REFERENCES `cananolab111`.`characterization` (`characterization_pk_id`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`nanoparticle`;
CREATE TABLE `cananolab111`.`nanoparticle` (
  `nanoparticle_pk_id` DECIMAL(22, 0) NOT NULL,
  `classification` VARCHAR(200) BINARY NULL,
  PRIMARY KEY (`nanoparticle_pk_id`),
  CONSTRAINT `sys_c00242938` FOREIGN KEY `sys_c00242938` (`nanoparticle_pk_id`)
    REFERENCES `cananolab111`.`sample` (`sample_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`nanoparticle_char`;
CREATE TABLE `cananolab111`.`nanoparticle_char` (
  `characterization_pk_id` DECIMAL(22, 0) NOT NULL,
  `nanoparticle_pk_id` DECIMAL(22, 0) NOT NULL,
  PRIMARY KEY (`characterization_pk_id`, `nanoparticle_pk_id`),
  CONSTRAINT `sys_c00242939` FOREIGN KEY `sys_c00242939` (`nanoparticle_pk_id`)
    REFERENCES `cananolab111`.`nanoparticle` (`nanoparticle_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`particle_function`;
CREATE TABLE `cananolab111`.`particle_function` (
  `particle_function_pk_id` DECIMAL(22, 0) NOT NULL,
  `type` VARCHAR(100) BINARY NULL,
  `activation_method` VARCHAR(500) BINARY NULL,
  `nanoparticle_pk_id` DECIMAL(22, 0) NULL,
  `identifier_name` VARCHAR(200) BINARY NULL,
  `description` VARCHAR(2000) BINARY NULL,
  PRIMARY KEY (`particle_function_pk_id`),
  CONSTRAINT `sys_c00242940` FOREIGN KEY `sys_c00242940` (`nanoparticle_pk_id`)
    REFERENCES `cananolab111`.`nanoparticle` (`nanoparticle_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`polymer_composition`;
CREATE TABLE `cananolab111`.`polymer_composition` (
  `is_cross_link` DECIMAL(22, 0) NULL,
  `cross_link_degree` DECIMAL(22, 0) NULL,
  `initiator` VARCHAR(200) BINARY NULL,
  `p_composition_pk_id` DECIMAL(22, 0) NOT NULL,
  PRIMARY KEY (`p_composition_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`project`;
CREATE TABLE `cananolab111`.`project` (
  `project_pk_id` DECIMAL(22, 0) NOT NULL,
  `project_name` VARCHAR(200) BINARY NULL,
  `description` VARCHAR(4000) BINARY NULL,
  PRIMARY KEY (`project_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`project_sample`;
CREATE TABLE `cananolab111`.`project_sample` (
  `sample_pk_id` DECIMAL(22, 0) NOT NULL,
  `project_pk_id` DECIMAL(22, 0) NOT NULL,
  PRIMARY KEY (`sample_pk_id`, `project_pk_id`),
  CONSTRAINT `sys_c00242919` FOREIGN KEY `sys_c00242919` (`project_pk_id`)
    REFERENCES `cananolab111`.`project` (`project_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `sys_c00242920` FOREIGN KEY `sys_c00242920` (`sample_pk_id`)
    REFERENCES `cananolab111`.`sample` (`sample_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`protocol`;
CREATE TABLE `cananolab111`.`protocol` (
  `protocol_pk_id` DECIMAL(22, 0) NOT NULL,
  `description` VARCHAR(2000) BINARY NULL,
  `protocol_name` VARCHAR(200) BINARY NULL,
  PRIMARY KEY (`protocol_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`report`;
CREATE TABLE `cananolab111`.`report` (
  `report_pk_id` DECIMAL(22, 0) NOT NULL,
  PRIMARY KEY (`report_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`run`;
CREATE TABLE `cananolab111`.`run` (
  `run_pk_id` DECIMAL(22, 0) NOT NULL,
  `run_name` VARCHAR(500) BINARY NULL,
  `description` VARCHAR(4000) BINARY NULL,
  `created_by` VARCHAR(200) BINARY NULL,
  `created_date` DATETIME NULL,
  `assay_pk_id` DECIMAL(22, 0) NULL,
  `run_by` VARCHAR(200) BINARY NULL,
  `run_date` DATETIME NULL,
  PRIMARY KEY (`run_pk_id`),
  CONSTRAINT `sys_c00242921` FOREIGN KEY `sys_c00242921` (`assay_pk_id`)
    REFERENCES `cananolab111`.`assay` (`assay_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`run_input_file`;
CREATE TABLE `cananolab111`.`run_input_file` (
  `input_file_pk_id` DECIMAL(22, 0) NULL,
  `run_pk_id` DECIMAL(22, 0) NULL,
  `data_status_pk_id` DECIMAL(22, 0) NULL
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`run_output_file`;
CREATE TABLE `cananolab111`.`run_output_file` (
  `output_file_pk_id` DECIMAL(22, 0) NULL,
  `run_pk_id` DECIMAL(22, 0) NULL,
  `data_status_pk_id` DECIMAL(22, 0) NULL
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`run_sample_container`;
CREATE TABLE `cananolab111`.`run_sample_container` (
  `comments` VARCHAR(4000) BINARY NULL,
  `run_sample_container_pk_id` DECIMAL(22, 0) NOT NULL,
  `created_by` VARCHAR(200) BINARY NULL,
  `created_date` DATETIME NULL,
  `run_pk_id` DECIMAL(22, 0) NULL,
  `sample_container_pk_id` DECIMAL(22, 0) NULL,
  `status` VARCHAR(20) BINARY NULL,
  `reason` VARCHAR(2000) BINARY NULL,
  `data_status_pk_id` DECIMAL(22, 0) NULL,
  PRIMARY KEY (`run_sample_container_pk_id`),
  CONSTRAINT `sys_c00242922` FOREIGN KEY `sys_c00242922` (`sample_container_pk_id`)
    REFERENCES `cananolab111`.`sample_container` (`sample_container_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `sys_c00242923` FOREIGN KEY `sys_c00242923` (`run_pk_id`)
    REFERENCES `cananolab111`.`run` (`run_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `sys_c00242924` FOREIGN KEY `sys_c00242924` (`data_status_pk_id`)
    REFERENCES `cananolab111`.`data_status` (`data_status_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`sample`;
CREATE TABLE `cananolab111`.`sample` (
  `sample_pk_id` DECIMAL(22, 0) NOT NULL,
  `sample_sequence_id` DECIMAL(22, 0) NULL,
  `sample_type` VARCHAR(100) BINARY NULL,
  `description` VARCHAR(4000) BINARY NULL,
  `source_sample_id` VARCHAR(100) BINARY NULL,
  `solubility_description` VARCHAR(4000) BINARY NULL,
  `lot_id` VARCHAR(100) BINARY NULL,
  `lot_description` VARCHAR(4000) BINARY NULL,
  `number_of_containers` DECIMAL(22, 0) NULL,
  `general_comments` VARCHAR(4000) BINARY NULL,
  `received_date` DATETIME NULL,
  `created_by` VARCHAR(200) BINARY NULL,
  `created_date` DATETIME NULL,
  `source_pk_id` DECIMAL(22, 0) NULL,
  `received_by` VARCHAR(200) BINARY NULL,
  `sample_name` VARCHAR(200) BINARY NULL,
  `sample_sop_pk_id` DECIMAL(22, 0) NULL,
  PRIMARY KEY (`sample_pk_id`),
  CONSTRAINT `sys_c00242925` FOREIGN KEY `sys_c00242925` (`sample_sop_pk_id`)
    REFERENCES `cananolab111`.`sample_sop` (`sample_sop_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `sys_c00242926` FOREIGN KEY `sys_c00242926` (`source_pk_id`)
    REFERENCES `cananolab111`.`source` (`source_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`sample_associated_file`;
CREATE TABLE `cananolab111`.`sample_associated_file` (
  `sample_pk_id` DECIMAL(22, 0) NOT NULL,
  `associated_file_pk_id` DECIMAL(22, 0) NOT NULL
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`sample_container`;
CREATE TABLE `cananolab111`.`sample_container` (
  `sample_container_pk_id` DECIMAL(22, 0) NOT NULL,
  `quantity` DECIMAL(22, 0) NULL,
  `concentration` DECIMAL(22, 0) NULL,
  `volume` DECIMAL(22, 0) NULL,
  `diluents_solvent` VARCHAR(500) BINARY NULL,
  `safety_precautions` VARCHAR(4000) BINARY NULL,
  `storage_conditions` VARCHAR(1000) BINARY NULL,
  `comments` VARCHAR(4000) BINARY NULL,
  `quantity_unit` VARCHAR(100) BINARY NULL,
  `concentration_unit` VARCHAR(100) BINARY NULL,
  `volume_unit` VARCHAR(100) BINARY NULL,
  `barcode` VARCHAR(50) BINARY NULL,
  `container_type` VARCHAR(200) BINARY NULL,
  `sample_pk_id` DECIMAL(22, 0) NULL,
  `is_derived` VARCHAR(20) BINARY NULL,
  `created_method` VARCHAR(500) BINARY NULL,
  `reason` VARCHAR(2000) BINARY NULL,
  `status` VARCHAR(20) BINARY NULL,
  `storage_pk_id` DECIMAL(22, 0) NULL,
  `created_date` DATETIME NULL,
  `created_by` VARCHAR(200) BINARY NULL,
  `name` VARCHAR(200) BINARY NULL,
  `data_status_pk_id` DECIMAL(22, 0) NULL,
  PRIMARY KEY (`sample_container_pk_id`),
  CONSTRAINT `sys_c00242927` FOREIGN KEY `sys_c00242927` (`storage_pk_id`)
    REFERENCES `cananolab111`.`storage` (`storage_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `sys_c00242928` FOREIGN KEY `sys_c00242928` (`sample_pk_id`)
    REFERENCES `cananolab111`.`sample` (`sample_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `sys_c00242929` FOREIGN KEY `sys_c00242929` (`data_status_pk_id`)
    REFERENCES `cananolab111`.`data_status` (`data_status_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`sample_report`;
CREATE TABLE `cananolab111`.`sample_report` (
  `sample_pk_id` DECIMAL(22, 0) NULL,
  `file_pk_id` DECIMAL(22, 0) NULL
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`sample_sop`;
CREATE TABLE `cananolab111`.`sample_sop` (
  `sample_sop_pk_id` DECIMAL(22, 0) NOT NULL,
  `description` VARCHAR(2000) BINARY NULL,
  `sop_name` VARCHAR(200) BINARY NULL,
  PRIMARY KEY (`sample_sop_pk_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`sample_type`;
CREATE TABLE `cananolab111`.`sample_type` (
  `sample_type_pk_id` DECIMAL(22, 0) NOT NULL,
  `sample_type_name` VARCHAR(200) BINARY NULL
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`shape`;
CREATE TABLE `cananolab111`.`shape` (
  `shape_pk_id` DECIMAL(22, 0) NOT NULL,
  `max_dimension` DECIMAL(22, 0) NULL,
  `min_dimension` DECIMAL(22, 0) NULL,
  `type` VARCHAR(100) BINARY NULL,
  PRIMARY KEY (`shape_pk_id`),
  CONSTRAINT `sys_c00242941` FOREIGN KEY `sys_c00242941` (`shape_pk_id`)
    REFERENCES `cananolab111`.`characterization` (`characterization_pk_id`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`solubility`;
CREATE TABLE `cananolab111`.`solubility` (
  `solubility_pk_id` DECIMAL(22, 0) NOT NULL,
  `solvent` VARCHAR(200) BINARY NULL,
  `critical_concentration` DECIMAL(22, 0) NULL,
  `concentration_unit` VARCHAR(100) BINARY NULL,
  `is_soluble` DECIMAL(22, 0) NULL,
  PRIMARY KEY (`solubility_pk_id`),
  CONSTRAINT `sys_c00242942` FOREIGN KEY `sys_c00242942` (`solubility_pk_id`)
    REFERENCES `cananolab111`.`characterization` (`characterization_pk_id`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`source`;
CREATE TABLE `cananolab111`.`source` (
  `source_pk_id` DECIMAL(22, 0) NOT NULL,
  `organization_name` VARCHAR(200) BINARY NULL,
  `address` VARCHAR(200) BINARY NULL,
  `city` VARCHAR(100) BINARY NULL,
  `state` VARCHAR(100) BINARY NULL,
  `country` VARCHAR(100) BINARY NULL,
  `postal_code` VARCHAR(10) BINARY NULL,
  PRIMARY KEY (`source_pk_id`),
  UNIQUE INDEX `unique_name` (`organization_name`(200))
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`source_contact`;
CREATE TABLE `cananolab111`.`source_contact` (
  `contact_pk_id` DECIMAL(38, 0) NOT NULL,
  `source_pk_id` DECIMAL(22, 0) NOT NULL,
  PRIMARY KEY (`contact_pk_id`, `source_pk_id`),
  CONSTRAINT `sys_c00242930` FOREIGN KEY `sys_c00242930` (`source_pk_id`)
    REFERENCES `cananolab111`.`source` (`source_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `sys_c00242931` FOREIGN KEY `sys_c00242931` (`contact_pk_id`)
    REFERENCES `cananolab111`.`contact` (`contact_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`stability`;
CREATE TABLE `cananolab111`.`stability` (
  `stability_pk_id` DECIMAL(22, 0) NOT NULL,
  `long_term_storage` DECIMAL(22, 0) NULL,
  `long_term_storage_unit` VARCHAR(100) BINARY NULL,
  `short_term_storage` DECIMAL(22, 0) NULL,
  `short_term_storage_unit` VARCHAR(100) BINARY NULL,
  `stress_result` VARCHAR(500) BINARY NULL,
  `release_kinetics_description` VARCHAR(4000) BINARY NULL,
  `measurement_type` VARCHAR(100) BINARY NULL,
  `stressor_type` VARCHAR(100) BINARY NULL,
  `stressor_desc` VARCHAR(2000) BINARY NULL,
  `stressor_value` DECIMAL(22, 0) NULL,
  `stressor_value_unit` VARCHAR(100) BINARY NULL,
  PRIMARY KEY (`stability_pk_id`),
  CONSTRAINT `sys_c00242943` FOREIGN KEY `sys_c00242943` (`stability_pk_id`)
    REFERENCES `cananolab111`.`characterization` (`characterization_pk_id`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`storage`;
CREATE TABLE `cananolab111`.`storage` (
  `storage_pk_id` DECIMAL(22, 0) NOT NULL,
  `storage_location` VARCHAR(500) BINARY NULL,
  `storage_type_id` DECIMAL(22, 0) NULL,
  `storage_type` VARCHAR(200) BINARY NULL,
  PRIMARY KEY (`storage_pk_id`),
  CONSTRAINT `sys_c00242932` FOREIGN KEY `sys_c00242932` (`storage_type_id`)
    REFERENCES `cananolab111`.`storage_type` (`storage_type_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`storage_type`;
CREATE TABLE `cananolab111`.`storage_type` (
  `storage_type_id` DECIMAL(22, 0) NOT NULL,
  `storage_type` VARCHAR(200) BINARY NULL,
  PRIMARY KEY (`storage_type_id`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`surface`;
CREATE TABLE `cananolab111`.`surface` (
  `surface_area` DECIMAL(22, 0) NULL,
  `surface_area_unit` VARCHAR(100) BINARY NULL,
  `zeta_potential` DECIMAL(22, 0) NULL,
  `charge` DECIMAL(22, 0) NULL,
  `charge_unit` VARCHAR(100) BINARY NULL,
  `is_hydrophobic` DECIMAL(22, 0) NULL,
  `surface_pk_id` DECIMAL(22, 0) NOT NULL,
  PRIMARY KEY (`surface_pk_id`),
  CONSTRAINT `sys_c00242944` FOREIGN KEY `sys_c00242944` (`surface_pk_id`)
    REFERENCES `cananolab111`.`characterization` (`characterization_pk_id`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`surface_chemistry`;
CREATE TABLE `cananolab111`.`surface_chemistry` (
  `surface_chemistry_pk_id` DECIMAL(22, 0) NOT NULL,
  `molecule_name` VARCHAR(200) BINARY NULL,
  `surface_pk_id` DECIMAL(22, 0) NULL,
  `number_molecule` DECIMAL(22, 0) NULL,
  `list_index` DECIMAL(22, 0) NULL,
  PRIMARY KEY (`surface_chemistry_pk_id`),
  CONSTRAINT `sys_c00242945` FOREIGN KEY `sys_c00242945` (`surface_pk_id`)
    REFERENCES `cananolab111`.`surface` (`surface_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`surface_group`;
CREATE TABLE `cananolab111`.`surface_group` (
  `surface_group_pk_id` DECIMAL(22, 0) NOT NULL,
  `name` VARCHAR(100) BINARY NULL,
  `modifier` VARCHAR(100) BINARY NULL,
  `d_composition_pk_id` DECIMAL(22, 0) NULL,
  `list_index` DECIMAL(22, 0) NULL,
  PRIMARY KEY (`surface_group_pk_id`),
  CONSTRAINT `sys_c00242946` FOREIGN KEY `sys_c00242946` (`d_composition_pk_id`)
    REFERENCES `cananolab111`.`dendrimer_composition` (`d_composition_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`table_data`;
CREATE TABLE `cananolab111`.`table_data` (
  `table_data_pk_id` DECIMAL(22, 0) NOT NULL,
  `type` VARCHAR(100) BINARY NULL,
  `value` DECIMAL(22, 0) NULL,
  `value_unit` VARCHAR(100) BINARY NULL,
  `char_table_pk_id` DECIMAL(22, 0) NULL,
  `list_index` DECIMAL(22, 0) NULL,
  `control_name` VARCHAR(200) BINARY NULL,
  `control_type` VARCHAR(100) BINARY NULL,
  PRIMARY KEY (`table_data_pk_id`),
  CONSTRAINT `sys_c00242947` FOREIGN KEY `sys_c00242947` (`char_table_pk_id`)
    REFERENCES `cananolab111`.`characterization_table` (`char_table_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cananolab111`.`table_data_condition`;
CREATE TABLE `cananolab111`.`table_data_condition` (
  `table_data_cond_pk_id` DECIMAL(22, 0) NOT NULL,
  `type` VARCHAR(100) BINARY NULL,
  `value` DECIMAL(22, 0) NULL,
  `value_unit` VARCHAR(100) BINARY NULL,
  `table_data_pk_id` DECIMAL(22, 0) NULL,
  `list_index` DECIMAL(22, 0) NULL,
  PRIMARY KEY (`table_data_cond_pk_id`),
  CONSTRAINT `sys_c00242948` FOREIGN KEY `sys_c00242948` (`table_data_pk_id`)
    REFERENCES `cananolab111`.`table_data` (`table_data_pk_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
)
ENGINE = INNODB;



-- -------------------------------------
-- Views

 DROP VIEW IF EXISTS `cananolab111`.`view_protocol_file`;
 CREATE OR REPLACE VIEW `cananolab111`.`view_protocol_file` (PROTOCOL_FILE_PK_ID, FILE_NAME, FILE_TYPE_EXTENSION, STATUS, REASON, FILE_URI, VERSION, CREATED_BY, CREATED_DATE, PROTOCOL_PK_ID) AS
 select FILE_PK_ID,
 	FILE_NAME,
 	FILE_TYPE_EXTENSION,
 	STATUS,
 	REASON,
 	FILE_URI,
 	VERSION,
 	CREATED_BY,
 	CREATED_DATE,
 	PROTOCOL_PK_ID from lab_file where File_source_type = 'PROTOCOL';

 DROP VIEW IF EXISTS `cananolab111`.`view_sample_sop_file`;
 CREATE OR REPLACE VIEW `cananolab111`.`view_sample_sop_file` (SOP_FILE_PK_ID, FILE_NAME, FILE_TYPE_EXTENSION, STATUS, REASON, FILE_URI, VERSION, CREATED_BY, CREATED_DATE, SAMPLE_SOP_PK_ID) AS
 select FILE_PK_ID,
 	FILE_NAME,
 	FILE_TYPE_EXTENSION,
 	STATUS,
 	REASON,
 	FILE_URI,
 	VERSION,
 	CREATED_BY,
 	CREATED_DATE,
 	SAMPLE_SOP_pk_ID from lab_file where File_source_type = 'SOP';



SET FOREIGN_KEY_CHECKS = 1;

-- ----------------------------------------------------------------------
-- EOF

