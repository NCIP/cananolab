package gov.nih.nci.cagrid.cananolab.service;

import gov.nih.nci.cananolab.domain.common.DerivedBioAssayData;
import gov.nih.nci.cananolab.domain.common.DerivedDatum;
import gov.nih.nci.cananolab.domain.common.Instrument;
import gov.nih.nci.cananolab.domain.common.InstrumentConfiguration;
import gov.nih.nci.cananolab.domain.common.Keyword;
import gov.nih.nci.cananolab.domain.common.LabFile;
import gov.nih.nci.cananolab.domain.common.Protocol;
import gov.nih.nci.cananolab.domain.common.ProtocolFile;
import gov.nih.nci.cananolab.domain.common.Report;
import gov.nih.nci.cananolab.domain.common.Source;
import gov.nih.nci.cananolab.domain.particle.NanoparticleSample;
import gov.nih.nci.cananolab.domain.particle.characterization.Characterization;
import gov.nih.nci.cananolab.domain.particle.characterization.physical.SurfaceChemistry;
import gov.nih.nci.cananolab.domain.particle.samplecomposition.Function;
import gov.nih.nci.cananolab.domain.particle.samplecomposition.SampleComposition;
import gov.nih.nci.cananolab.domain.particle.samplecomposition.Target;
import gov.nih.nci.cananolab.domain.particle.samplecomposition.base.NanoparticleEntity;
import gov.nih.nci.cananolab.domain.particle.samplecomposition.chemicalassociation.AssociatedElement;
import gov.nih.nci.cananolab.domain.particle.samplecomposition.chemicalassociation.ChemicalAssociation;
import gov.nih.nci.cananolab.domain.particle.samplecomposition.functionalization.ActivationMethod;
import gov.nih.nci.cananolab.service.common.helper.FileServiceHelper;
import gov.nih.nci.cananolab.service.particle.helper.NanoparticleCharacterizationServiceHelper;
import gov.nih.nci.cananolab.service.particle.helper.NanoparticleCompositionServiceHelper;
import gov.nih.nci.cananolab.service.particle.helper.NanoparticleSampleServiceHelper;
import gov.nih.nci.cananolab.service.protocol.helper.ProtocolServiceHelper;
import gov.nih.nci.cananolab.service.report.helper.ReportServiceHelper;
import gov.nih.nci.cananolab.system.applicationservice.CustomizedApplicationService;
import gov.nih.nci.cananolab.util.StringUtils;
import gov.nih.nci.system.client.ApplicationServiceProvider;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

/**
 * TODO:I am the service side implementation class. IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class CaNanoLabServiceImpl extends CaNanoLabServiceImplBase {
	List<String> publicDataIds;
	List<String> publicDataIdsAsNumbers;

	public CaNanoLabServiceImpl() throws RemoteException {
		super();
		try {
			CustomizedApplicationService appService = (CustomizedApplicationService) ApplicationServiceProvider
					.getApplicationService();
			publicDataIds = appService.getPublicData();
			// remove non-numbers
			publicDataIdsAsNumbers = new ArrayList<String>();
			for (String id : publicDataIds) {
				if (id.matches("^\\d+$")) {
					publicDataIdsAsNumbers.add(id);
				}
			}
		} catch (Exception e) {
			throw new RemoteException(
					"Can't get public data for remote service.");
		}
	}

	public gov.nih.nci.cananolab.domain.particle.samplecomposition.functionalization.ActivationMethod getActivationMethodByFunctionalizingEntityId(
			java.lang.String id) throws RemoteException {
		NanoparticleCompositionServiceHelper helper = new NanoparticleCompositionServiceHelper();
		try {
			return helper.findActivationMethodByFunctionalizingEntityId(id);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding remote activation method by functionalizing entity id.");
		}
	}

	public gov.nih.nci.cananolab.domain.particle.samplecomposition.chemicalassociation.AssociatedElement getAssociatedElementAByChemicalAssociationId(
			java.lang.String id) throws RemoteException {
		NanoparticleCompositionServiceHelper helper = new NanoparticleCompositionServiceHelper();
		try {
			return helper.findAssociatedElementA(id);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding remote associated elemen A by chemical association id.");
		}
	}

	public gov.nih.nci.cananolab.domain.particle.samplecomposition.chemicalassociation.AssociatedElement getAssociatedElementBByChemicalAssociationId(
			java.lang.String id) throws RemoteException {
		NanoparticleCompositionServiceHelper helper = new NanoparticleCompositionServiceHelper();
		try {
			return helper.findAssociatedElementB(id);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding remote associated element B by chemical association id.");
		}
	}

	public gov.nih.nci.cananolab.domain.particle.samplecomposition.chemicalassociation.ChemicalAssociation[] getChemicalAssociationsByCompositionId(
			java.lang.String id) throws RemoteException {
		NanoparticleCompositionServiceHelper helper = new NanoparticleCompositionServiceHelper();
		try {
			List<ChemicalAssociation> assocs = helper
					.findChemicalAssociationsByCompositionId(id);
			return assocs.toArray(new ChemicalAssociation[0]);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding remote chemical associations by composition id.");
		}
	}

	public gov.nih.nci.cananolab.domain.common.DerivedBioAssayData[] getDerivedBioAssayDatasByCharacterizationId(
			java.lang.String id) throws RemoteException {
		NanoparticleCharacterizationServiceHelper helper = new NanoparticleCharacterizationServiceHelper();
		try {
			List<DerivedBioAssayData> bioassays = helper
					.findDerivedBioAssayDataByCharacterizationId(id);
			return bioassays.toArray(new DerivedBioAssayData[0]);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding remote derived bioassay data for characterization id.");
		}
	}

	public gov.nih.nci.cananolab.domain.particle.samplecomposition.Function[] getFunctionsByFunctionalizingEntityId(
			java.lang.String id) throws RemoteException {
		NanoparticleCompositionServiceHelper helper = new NanoparticleCompositionServiceHelper();
		try {
			List<Function> functions = helper
					.findFunctionsByFunctionalizingEntityId(id);
			return functions.toArray(new Function[0]);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding remote functions for functionalizing entity id.");
		}
	}

	public gov.nih.nci.cananolab.domain.particle.samplecomposition.Function[] getInherentFunctionsByComposingElementId(
			java.lang.String id) throws RemoteException {
		NanoparticleCompositionServiceHelper helper = new NanoparticleCompositionServiceHelper();
		try {
			List<Function> functions = helper
					.findInherentFunctionsByComposingElementId(id);
			return functions.toArray(new Function[0]);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding remote inherent functions for composing element id.");
		}
	}

	public gov.nih.nci.cananolab.domain.common.Instrument getInstrumentByInstrumentConfigurationId(
			java.lang.String id) throws RemoteException {
		NanoparticleCharacterizationServiceHelper helper = new NanoparticleCharacterizationServiceHelper();
		try {
			return helper.findInstrumentByInstrumentConfigurationId(id);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding remote instrument configuration by  id.");
		}
	}

	public gov.nih.nci.cananolab.domain.common.InstrumentConfiguration getInstrumentConfigurationByCharacterizationId(
			java.lang.String id) throws RemoteException {
		NanoparticleCharacterizationServiceHelper helper = new NanoparticleCharacterizationServiceHelper();
		try {
			return helper.findInstrumentConfigurationByCharacterizationId(id);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding remote instrument configuration for characterization id");
		}
	}

	public gov.nih.nci.cananolab.domain.common.Keyword[] getKeywordsByFileId(
			java.lang.String id) throws RemoteException {
		FileServiceHelper helper = new FileServiceHelper();
		try {
			List<Keyword> keywords = helper.findKeywordsByFileId(id);
			return keywords.toArray(new Keyword[0]);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding remote keywords by file id.");
		}
	}

	public gov.nih.nci.cananolab.domain.common.Keyword[] getKeywordsByParticleSampleId(
			java.lang.String id) throws RemoteException {
		NanoparticleSampleServiceHelper helper = new NanoparticleSampleServiceHelper();
		try {
			List<Keyword> keywords = helper
					.findKeywordsForNanoparticleSampleId(id);
			return keywords.toArray(new Keyword[0]);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding keywords by nanoparticle sample id.");
		}
	}

	public gov.nih.nci.cananolab.domain.common.LabFile getLabFileByDerivedBioAssayDataId(
			java.lang.String id) throws RemoteException {
		NanoparticleCharacterizationServiceHelper helper = new NanoparticleCharacterizationServiceHelper();
		try {
			return helper.findLabFileByDerivedBioAssayDataId(id);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding remote lab file by derived bioassay data id.");
		}
	}

	public gov.nih.nci.cananolab.domain.common.LabFile[] getLabFilesByCompositionInfoId(
			java.lang.String id, java.lang.String className)
			throws RemoteException {
		FileServiceHelper helper = new FileServiceHelper();
		try {
			List<LabFile> files = helper.findFilesByCompositionInfoId(id,
					className);
			return files.toArray(new LabFile[0]);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding remote lab files by composition info");
		}
	}

	public gov.nih.nci.cananolab.domain.particle.NanoparticleSample[] getNanoparticleSamplesBy(
			java.lang.String particleSource,
			java.lang.String[] nanoparticleEntityClassNames,
			java.lang.String[] functionalizingEntityClassNames,
			java.lang.String[] functionClassNames,
			java.lang.String[] characterizationClassNames,
			java.lang.String[] words) throws RemoteException {
		try {
			NanoparticleSampleServiceHelper helper = new NanoparticleSampleServiceHelper();
			List<NanoparticleSample> particleSampleList = helper
					.findNanoparticleSamplesBy(particleSource,
							nanoparticleEntityClassNames, null,
							functionalizingEntityClassNames, null,
							functionClassNames, null,
							characterizationClassNames, words);
			List<NanoparticleSample> filteredParticleSample = getPublicData(particleSampleList);
			return filteredParticleSample.toArray(new NanoparticleSample[0]);
		} catch (Exception e) {
			throw new RemoteException(
					"Can't get nanoparticle samples by the given parameters");
		}
	}

	public gov.nih.nci.cananolab.domain.common.ProtocolFile getProtocolFileByCharacterizationId(
			java.lang.String id) throws RemoteException {
		NanoparticleCharacterizationServiceHelper helper = new NanoparticleCharacterizationServiceHelper();
		try {
			return helper.findProtocolFileByCharacterizationId(id);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding remote protocol file by characterization id.");
		}
	}

	public gov.nih.nci.cananolab.domain.common.ProtocolFile[] getProtocolFilesBy(
			java.lang.String protocolType, java.lang.String protocolName,
			java.lang.String protocolFileTitle) throws RemoteException {
		try {
			ProtocolServiceHelper helper = new ProtocolServiceHelper();
			List<ProtocolFile> protocolFileList = helper.findProtocolFilesBy(
					protocolType, protocolName, protocolFileTitle);
			List<Report> filteredProtocolFiles = getPublicData(protocolFileList);
			return filteredProtocolFiles.toArray(new ProtocolFile[0]);
		} catch (Exception e) {
			throw new RemoteException(
					"Can't get protocol files by the given parameters");
		}
	}

	public gov.nih.nci.cananolab.domain.common.Report[] getReportsBy(
			java.lang.String reportTitle, java.lang.String reportCategory,
			java.lang.String[] nanoparticleEntityClassNames,
			java.lang.String[] functionalizingEntityClassNames,
			java.lang.String[] functionClassNames) throws RemoteException {
		try {
			ReportServiceHelper helper = new ReportServiceHelper();
			List<Report> reportList = helper.findReportsBy(reportTitle,
					reportCategory, nanoparticleEntityClassNames, null,
					functionalizingEntityClassNames, null, functionClassNames,
					null);

			List<Report> filteredReports = getPublicData(reportList);
			return filteredReports.toArray(new Report[0]);
		} catch (Exception e) {
			throw new RemoteException(
					"Can't get reports by the given parameters");
		}
	}

	public gov.nih.nci.cananolab.domain.particle.characterization.physical.SurfaceChemistry[] getSurfaceChemistriesBySurfaceId(
			java.lang.String id) throws RemoteException {
		NanoparticleCharacterizationServiceHelper helper = new NanoparticleCharacterizationServiceHelper();
		try {
			List<SurfaceChemistry> chemistries = helper
					.findSurfaceChemistriesBySurfaceId(id);
			return chemistries.toArray(new SurfaceChemistry[0]);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding remote surface chemistry by surface id.");
		}
	}

	public gov.nih.nci.cananolab.domain.particle.samplecomposition.Target[] getTargetsByFunctionId(
			java.lang.String id) throws RemoteException {
		NanoparticleCompositionServiceHelper helper = new NanoparticleCompositionServiceHelper();
		try {
			List<Target> targets = helper.findTargetsByFunctionId(id);
			return targets.toArray(new Target[0]);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding remote targets for function id.");
		}
	}

	public java.lang.String[] getCharacterizationClassNamesByParticleId(
			java.lang.String id) throws RemoteException {
		try {
			NanoparticleSampleServiceHelper helper = new NanoparticleSampleServiceHelper();
			return helper.getCharacterizationClassNames(id);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding characterization class names by particle id.");
		}
	}

	public java.lang.String[] getFunctionalizingEntityClassNamesByParticleId(
			java.lang.String id) throws RemoteException {
		try {
			NanoparticleSampleServiceHelper helper = new NanoparticleSampleServiceHelper();
			return helper.getFunctionalizingEntityClassNames(id);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding functionalizing entity class names by particle id.");
		}
	}

	public java.lang.String[] getFunctionClassNamesByParticleId(
			java.lang.String id) throws RemoteException {
		try {
			NanoparticleSampleServiceHelper helper = new NanoparticleSampleServiceHelper();
			return helper.getFunctionClassNames(id);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding function class names by particle id.");
		}
	}

	public java.lang.String[] getNanoparticleEntityClassNamesByParticleId(
			java.lang.String id) throws RemoteException {
		try {
			NanoparticleSampleServiceHelper helper = new NanoparticleSampleServiceHelper();
			return helper.getNanoparticleEntityClassNames(id);
		} catch (Exception e) {
			throw new RemoteException(
					"Error finding nanoparticle entity class names by particle id.");
		}
	}

	/**
	 * This method is also intended to be used in the
	 * CustomizedSDK4QueryProcessor in the same package. Filter out non-public
	 * data.
	 * 
	 * @param rawObjects
	 * @return
	 * @throws Exception
	 */
	List getPublicData(List rawObjects) throws RemoteException {
		try {
			CustomizedApplicationService appService = (CustomizedApplicationService) ApplicationServiceProvider
					.getApplicationService();
			List processed = new ArrayList();
			if (publicDataIds.isEmpty()) {
				return processed;
			}
			if (rawObjects == null || rawObjects.isEmpty()) {
				return processed;
			}
			for (Object obj : rawObjects) {
				String data = null;
				if (obj instanceof NanoparticleSample) {
					data = ((NanoparticleSample) obj).getName();
					if (data != null && publicDataIds.contains(data)) {
						processed.add(obj);
					}
				} else {
					data = getIdString(obj);
					if (data != null && publicDataIdsAsNumbers.contains(data)) {
						processed.add(obj);
					}
				}
			}
			return processed;
		} catch (Exception e) {
			throw new RemoteException("Can't find public data.", e);
		}
	}

	// append where clause of public IDs
	String modifyPublicHQL(String hql, String targetName)
			throws RemoteException {
		if (publicDataIds == null || publicDataIds.isEmpty()) {
			return hql;
		}
		String modifiedHql = hql;
		if (hql.contains("where")) {
			modifiedHql += " and (";
		} else {
			modifiedHql += " where ";
		}
		List<String> subqueryList = new ArrayList<String>();
		if (targetName.contains("NanoparticleSample")) {
			for (String id : publicDataIds) {
				subqueryList.add("__TargetAlias__.name=?");
			}
		} else {
			for (String id : publicDataIdsAsNumbers) {
				subqueryList.add("__TargetAlias__.id=?");
			}
		}
		String subquery = StringUtils.join(subqueryList, " or ");
		if (hql.contains("where")) {
			modifiedHql += subquery + ")";
		} else {
			modifiedHql += subquery;
		}
		return modifiedHql;
	}

	List<Object> modifyPublicHQLParameters(List<Object> parameters,
			String targetName) {
		if (publicDataIds == null || publicDataIds.isEmpty()) {
			return parameters;
		}
		List<Object> newParameters = new ArrayList<Object>();
		if (!targetName.contains("NanoparticleSample")) {
			for (String id : publicDataIdsAsNumbers) {
				newParameters.add(new Long(id));
			}
		} else {
			newParameters.addAll(publicDataIds);
		}
		return newParameters;
	}

	private String getIdString(Object obj) {
		String id = null;
		if (obj instanceof LabFile) {
			id = ((LabFile) obj).getId().toString();
		} else if (obj instanceof Source) {
			id = ((Source) obj).getId().toString();
		} else if (obj instanceof SampleComposition) {
			id = ((SampleComposition) obj).getId().toString();
		} else if (obj instanceof Characterization) {
			id = ((Characterization) obj).getId().toString();
		} else if (obj instanceof Keyword) {
			id = ((Keyword) obj).getId().toString();
		} else if (obj instanceof Protocol) {
			id = ((Protocol) obj).getId().toString();
		} else if (obj instanceof NanoparticleEntity) {
			id = ((NanoparticleEntity) obj).getId().toString();
		} else if (obj instanceof AssociatedElement) {
			id = ((AssociatedElement) obj).getId().toString();
		} else if (obj instanceof ChemicalAssociation) {
			id = ((ChemicalAssociation) obj).getId().toString();
		} else if (obj instanceof Function) {
			id = ((Function) obj).getId().toString();
		} else if (obj instanceof Target) {
			id = ((Target) obj).getId().toString();
		} else if (obj instanceof ActivationMethod) {
			id = ((ActivationMethod) obj).getId().toString();
		} else if (obj instanceof Instrument) {
			id = ((Instrument) obj).getId().toString();
		} else if (obj instanceof InstrumentConfiguration) {
			id = ((InstrumentConfiguration) obj).getId().toString();
		} else if (obj instanceof DerivedBioAssayData) {
			id = ((DerivedBioAssayData) obj).getId().toString();
		} else if (obj instanceof DerivedDatum) {
			id = ((DerivedDatum) obj).getId().toString();
		} else if (obj instanceof SurfaceChemistry) {
			id = ((SurfaceChemistry) obj).getId().toString();
		}
		return id;
	}
}
