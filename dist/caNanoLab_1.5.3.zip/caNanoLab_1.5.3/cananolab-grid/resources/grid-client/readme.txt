The following steps are required for your grid service client code to work against the caNanoLab grid service:

1.  Place the file client-config.wsdd to your classpath.

2.  Extract the jars from caGrid-jars.zip and caNanoLabService-clientJars.zip and place them to the classpath.

3.  Download the file https://ncisvn.nci.nih.gov/svn/commonlibrary/trunk/techstack-2006/os-independent/ws-core-enum-4.0.3.zip
    and extract the jars from the lib subdirectory and place them to the classpath.

see https://wiki.nci.nih.gov/display/caNanoLab/caNanoLab+Grid+Services for example grid service client code. 