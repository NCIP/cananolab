This directory contains jars needed for caCORE SDK.  Removed antlr-2.7.6.jar, commons-logging-1.1.jar because 
antlr-2.7.2.jar and commons-logging-1.0.4.jar was required for struts 1.3.10.